<?php 
	
	require '../model/User.php';

	if ($_SERVER['REQUEST_METHOD'] === "POST") {
		$isValid = true;
		$username = sanitize($_POST['uname']);
		$password = sanitize($_POST['password']);
		$msg1 = "";
		$msg2 = "";
		$msg3 = "";

		if (empty($username)) {
			$msg1 = "Please fill up the username";
			$isValid = false;
		}
		if (empty($password)) {
			$msg2 = "Please fill up the password";
			$isValid = false;
		}

		if ($isValid) {
			if (credentials($username, $password)) {
				header("Location: ../views/home.html");
			}
			else {
				$msg3 = "Username or password does not match";
				header("Location: ../views/login.php?errMsg3=" . $msg3);
			}
		}
		else {
			$msg3 = "Please check your inputs";
			header("Location: ../views/login.php?errMsg3=" . $msg3);
		}

	}
	else {
		echo "Invalid Request";
	}

	function sanitize($data) {
		$data = htmlspecialchars($data);
		return $data;
	}
?>