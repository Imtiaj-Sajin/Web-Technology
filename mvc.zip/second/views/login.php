<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login Form</title>
</head>
<body>

	<form action="../controllers/LoginAction.php" method="post" novalidate>
		<label for="uname">Username:</label>
		<input type="text" name="uname" id="uname">
		<?php echo isset($_GET['errMsg1']) ? $_GET['errMsg1'] : ""; ?>

		<br><br>

		<label for="password">Password:</label>
		<input type="password" name="password" id="password">
		<?php echo isset($_GET['errMsg2']) ? $_GET['errMsg2'] : ""; ?>

		<br><br>

		<input type="submit" value="Login">

	</form>

	<?php echo isset($_GET['errMsg3']) ? $_GET['errMsg3'] : ""; ?>

</body>
</html>